import mongoose from "mongoose";
import AcademicClass from "../Models/academicClass.model.js";

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

const isAdmin = (req, res) => {
  if (!req.user || !req.user.roles?.includes("admin")) {
    res.status(403).json({ message: "Access denied" });
    return false;
  }
  return true;
};

// ===============================
// CREATE CLASS (admin only)
// ===============================
export const createClass = async (req, res) => {
  try {
    if (!isAdmin(req, res)) return;

    const { grade, section, academicYear, classTeachers } = req.body;

    // ---- Required fields check (MODEL-ALIGNED) ----
    if (
      !grade ||
      !section ||
      !academicYear ||
      !Array.isArray(classTeachers) ||
      classTeachers.length === 0
    ) {
      return res.status(400).json({
        message:
          "Missing fields. grade, section, academicYear and at least one classTeacher are required.",
      });
    }

    // ---- Validate teacher IDs ----
    for (const teacherId of classTeachers) {
      if (!isValidId(teacherId)) {
        return res
          .status(400)
          .json({ message: "Invalid teacher ID in classTeachers" });
      }
    }

    // ---- Prevent duplicate class ----
    const exists = await AcademicClass.findOne({
      grade,
      section,
      academicYear,
    });

    if (exists) {
      return res.status(409).json({ message: "Class already exists" });
    }

    // ---- CREATE CLASS (MODEL-COMPLIANT) ----
    const newClass = await AcademicClass.create({
      grade,
      section,
      academicYear,
      classTeachers,           // REQUIRED by model
      subjectTeachers: [],     // allowed empty
      createdBy: req.user._id, // REQUIRED by model
    });

    return res.status(201).json(newClass);
  } catch (err) {
    console.error("Create class error:", err);
    return res.status(500).json({
      message: "Server error while creating class",
      error: err.message,
    });
  }
};

// ===============================
// GET ALL CLASSES (admin only)
// ===============================
export const getAllClasses = async (req, res) => {
  try {
    if (!isAdmin(req, res)) return;

    const classes = await AcademicClass.find()
      .populate("classTeachers", "name email")
      .populate("createdBy", "name email");

    res.json(classes);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// ===============================
// GET SINGLE CLASS (all roles)
// ===============================
export const getClassById = async (req, res) => {
  try {
    const { classId } = req.params;

    if (!isValidId(classId)) {
      return res.status(400).json({ message: "Invalid class id" });
    }

    const cls = await AcademicClass.findById(classId)
      .populate("classTeachers", "name email")
      .populate("subjectTeachers.teacher", "name email");

    if (!cls) {
      return res.status(404).json({ message: "Class not found" });
    }

    res.json(cls);
  } catch {
    res.status(500).json({ message: "Server error" });
  }
};

// ===============================
// ASSIGN CLASS TEACHERS (admin)
// ===============================
export const assignClassTeachers = async (req, res) => {
  try {
    if (!isAdmin(req, res)) return;

    const { classId } = req.params;
    const { teachers } = req.body;

    if (!isValidId(classId) || !Array.isArray(teachers) || teachers.length === 0) {
      return res.status(400).json({ message: "Invalid input" });
    }

    const cls = await AcademicClass.findByIdAndUpdate(
      classId,
      { classTeachers: teachers },
      { new: true }
    );

    if (!cls) {
      return res.status(404).json({ message: "Class not found" });
    }

    res.json(cls);
  } catch {
    res.status(500).json({ message: "Server error" });
  }
};

// ===============================
// ASSIGN SUBJECT TEACHERS (admin)
// ===============================
export const assignSubjectTeachers = async (req, res) => {
  try {
    if (!isAdmin(req, res)) return;

    const { classId } = req.params;
    const { subjects } = req.body;

    if (!isValidId(classId)) {
      return res.status(400).json({ message: "Invalid class id" });
    }

    const cls = await AcademicClass.findByIdAndUpdate(
      classId,
      { subjectTeachers: subjects },
      { new: true }
    );

    if (!cls) {
      return res.status(404).json({ message: "Class not found" });
    }

    res.json(cls);
  } catch {
    res.status(500).json({ message: "Server error" });
  }
};

// ===============================
// GET MY CLASSES (teacher)
// ===============================
export const getMyClasses = async (req, res) => {
  try {
    if (!req.user.roles?.includes("teacher")) {
      return res.status(403).json({ message: "Access denied" });
    }

    const classes = await AcademicClass.find({
      $or: [
        { classTeachers: req.user._id },
        { "subjectTeachers.teacher": req.user._id },
      ],
    });

    res.json(classes);
  } catch {
    res.status(500).json({ message: "Server error" });
  }
};
