export const DB_NAME = "SanskritiPreSchool";
